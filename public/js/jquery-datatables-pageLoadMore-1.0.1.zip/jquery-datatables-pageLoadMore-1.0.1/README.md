jQuery DataTables PageLoadMore
==============================

PageLoadMore is a plug-in for the jQuery DataTables that allows to load more content with "Load More" button.

More information and examples are available at
[gyrocode.com/articles/jquery-datatables-load-more-button](https://www.gyrocode.com/articles/jquery-datatables-load-more-button/).


Copyright
---------

Gyrocode LLC, [gyrocode.com](https://www.gyrocode.com)


License
-------

MIT License, [opensource.org/licenses/MIT](http://www.opensource.org/licenses/MIT)
